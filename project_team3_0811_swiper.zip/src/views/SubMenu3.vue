<template>
  <div>
    <div id="nav">
      <!-- nav_back -->
      <div>
        <div class="back">
          <router-link to="/">
            <img :src="head1" alt="뒤로가기" width="22" height="22" />
          </router-link>
        </div>
        <div class="mypage">
          <router-link to="/login" class="mypage"></router-link>
        </div>
      </div>
    </div>


    <div class="sub2_wrap">
      <div class="sub2_title">
        <p class="sub2_title_1">오늘</p>
        <p class="sub2_title_2">뭐 버거?</p>
      </div>
      <form class="search_area">
        <input type="text" class="sub2_search" />
        <button type="button" class="btn_search">
          <i class="fa-solid fa-magnifying-glass btn_search_font"></i>
        </button>
      </form>

      <p class="sub2_event_txt">이벤트</p>
      <div class="sub2_event">
        <img :src="event1" alt /> <!-- 수정한 부분 -->
      </div>
      <div class="sub2_now_ham">
        <p class="now_ham_title">오늘은 이거 버거!</p>
      </div>
      <div class="sub2_overflow">
        <div class="sub2_track">
          <div class="sub2_card">
            <div class="hamimg hamimg0">
              <img :src="burger1" alt />
            </div>
            <p class="ham_brand sub2_card_txt">맥도날드</p>
            <p class="ham_menu sub2_card_txt">쿼터파운더 치즈버거</p>
          </div>
          <div class="sub2_card">
            <div class="hamimg hamimg1"></div>
          </div>
          <div class="sub2_card">
            <div class="hamimg hamimg2"></div>
          </div>
          <div class="sub2_card">
            <div class="hamimg hamimg3"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      head1: require("../assets/header_back.svg"),
      event1: require("../assets/sub2event.png"),/* 수정한 부분 */
      burger1: require("../assets/card_burger1.png")
    };
  }
};
</script>

<style>
div {
  /* border: 1px solid red */
}
.sub2_wrap {
  max-width: 945px;
  min-width: 360px;

  margin: 0 auto;
}/* 수정한 부분 */
.sub2_title {
  margin-bottom: 10px;
}
.sub2_title p {
  text-align: left;
  font-size: 2em;
  padding-left: 20px;
}
.sub2_title_1 {
  font-weight: 400;
}
.sub2_title_2 {
  font-weight: bold;
}
.sub2_search {
  width: 100%;
  height: 40px;
  outline: 1px solid rgb(212, 212, 212);
  border-radius: 5px;
  margin-bottom: 20px;
}
.search_area {
  width: 95%;
  position: relative;
  margin: 0 auto;
}
.btn_search_font {
  font-size: 1.5em;
  position: absolute;
  top: 15%;
  right: 3%;
}

.sub2_event_txt {
  text-align: left;
  margin-left: 20px;
  font-size: 1.5em;
  font-weight: bold;
  margin-bottom: 10px;
}
.sub2_event {
  margin: 0 auto;
  width: 95%;
  height: auto;




} /* 수정한 부분 */
.sub2_event img{
  width: 100%;
  height: 100%;
 
}/* 수정한 부분 */

.hamimg0 img{
  width: 100%;
  height: 100%;
}

.now_ham_title {
  text-align: left;
  font-size: 1.7em;
  font-weight: bold;
  padding-left: 20px;
}
.sub2_overflow {
  width: 100vw;
  height: 400px;
  overflow: hidden;
}
.sub2_track {
  width: 3000px;
  height: 300px;
  display: flex;
}
.sub2_track > .sub2_card {
  width: 100vw;
  height: 300px;
}
.sub2_track > .sub2_card > .hamimg {
  width: 100%;
  height: 300px;
}
.sub2_card_txt{

  text-align: center;
  font-size: 1.4em;
  font-weight: bold;
}
.hamimg0 {
/*   background: url(../assets/card_burger1.png) no-repeat;
  background-size: cover;
  background-position: -20%; */
}
/* .hamimg1 {
  background: url(../assets/card_burger2.png) no-repeat;
  background-size: cover;
}
.hamimg2 {
  background: url(../assets/card_burger3.png) no-repeat;
  background-size: cover;
}
.hamimg3 {
  background: url(../assets/card_burger4.png) no-repeat;
  background-size: cover;
} */
</style>